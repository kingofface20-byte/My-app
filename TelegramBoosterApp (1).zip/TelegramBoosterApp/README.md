# Telegram Booster — اندروید اپ (GitHub Actions)

دا یوه ساده او بشپړه اندروید پروژه ده. سکیچویر ته اړتیا نشته — GitHub پخپله APK درته جوړوي.

## اوس اپ څه کوي

- Get Started تڼۍ کېکاږئ → یوازې "Welcome" ښکاره کیږي. بس همدومره. دا د راتلونکو برخو لپاره یوه پاکه بنسټ ده.

---

## ۱) دا پروژه GitHub ته لېږل

1. په GitHub کې یو نوی، خالي repository جوړ کړئ (public یا private دواړه کار کوي).
2. دا ټول فولډر (`TelegramBoosterApp`) هغه repository ته push کړئ. که له کمپیوټر نه کوئ:

   ```
   git init
   git add .
   git commit -m "first version"
   git branch -M main
   git remote add origin <ستاسو د repo لینک>
   git push -u origin main
   ```

   که غواړئ یوازې د GitHub ویب پاڼې له لارې، د "Add file → Upload files" په کارولو سره ټول فولډر pعني کولی شئ ورواچوئ.

## ۲) APK ترلاسه کول

1. کله چې push بشپړ شي، د خپل repository په مخ کې "Actions" ټبکې ته لاړ شئ.
2. "Build APK" نومې کار (workflow) به پخپله پیل شي (یا "Run workflow" کېکاږئ چې په لاس یې پیل کړئ).
3. کله چې کار پای ته ورسېد (شاوخوا ۳-۵ دقیقې)، لاندې یې "Artifacts" برخه کې `app-debug-apk` ښکاره کیږي — هغه ډاونلوډ کړئ. دننه یې `app-debug.apk` دی.
4. دا APK خپل موبایل ته واستوئ او نصب یې کړئ (که "Install unknown apps" اجازه غواړي، یوځل یې فعاله کړئ).

---

## ۳) فایلونه او دا چې وروسته چیرته تغیر راولئ

| غواړئ څه بدل کړئ | فایل |
|---|---|
| ډیزاین، متن، رنګونه، نوې سکرینونه | `app/src/main/assets/index.html` |
| نوې اجازه اعلانول (لکه notification) | `app/src/main/AndroidManifest.xml` |
| د اجازې غوښتلو کوډ (native) | `app/src/main/java/com/example/tgbooster/MainActivity.kt` |
| د اپ نوم | `app/src/main/res/values/strings.xml` |
| د اپ بسته نوم (applicationId)، نسخه | `app/build.gradle` |
| APK بیا جوړول | بس کوډ ته تغیر ورکړئ → `git push` → Actions ته لاړ شئ → APK ډاونلوډ کړئ |

### د نوې اجازې اضافه کولو بېلګه (مثلاً خبرتیاوې)

**ګام ۱ — `AndroidManifest.xml`** کې لاندې کرښه اضافه کړئ:
```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

**ګام ۲ — `MainActivity.kt`** کې (د کلاس دننه) دا اضافه کړئ:
```kotlin
private val permLauncher = registerForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
) { granted -> /* دلته پایله وکاروئ */ }
```
او بیا یې په `onCreate` کې وغواړئ:
```kotlin
permLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
```

کله چې اپ چلیږي، یو معمولي سیسټمي پوښتنه (popup) راځي او کارن "Allow" کېکاږي — Settings ته تلل نه غواړي.

### Accessibility اجازه

دا یوه ځانګړې قاعده لري: هیڅ اپ (حتی لویې شرکتونه) نشي کولی دا پخپله فعاله کړي — کارن باید تل پخپله د Settings → Accessibility څخه فعاله کړي. دا د اندروید خوندیتوب قانون دی، نه زما یا ستاسو د کوډ محدودیت. کله چې دا برخه اضافه کړو، زه به درته دقیق کوډ ورکړم چې کارن اسانه Settings ته یوسي.

---

## یادونه

- اوسنی applicationId (`com.example.tgbooster`) یوازې د ازموینې لپاره دی. که اپ خپور کول غواړئ، دا بايد ستاسو خپل ځانګړی نوم شي.
- د اپ icon اوس پیشفرض دی. کله چې غواړئ، زه کولی شم ستاسو خوښ icon ورته اضافه کړم.
