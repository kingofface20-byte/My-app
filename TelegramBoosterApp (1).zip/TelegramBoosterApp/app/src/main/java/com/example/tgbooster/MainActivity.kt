package com.example.tgbooster

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

/**
 * دا فایل یوازې یو WebView پرانیزي چې زموږ ډیزاین (assets/index.html) ښیي.
 *
 * نوی native فنکشن یا د اجازې غوښتلو کوډ هم دلته اضافه کیږي.
 * بیلګه (د POST_NOTIFICATIONS اجازه غوښتل، Android 13+):
 *
 *   private val permLauncher = registerForActivityResult(
 *       ActivityResultContracts.RequestPermission()
 *   ) { granted -> /* دلته پایله وکاروئ */ }
 *
 *   permLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
 *
 * یادونه: مخکې له دې چې دا کوډ کار وکړي، اړینه اجازه باید لومړی
 * په AndroidManifest.xml کې هم اعلان شي.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
